Hope you enjoy this font.
By installing or using this font, you are agree to the Product Usage Agreement:

- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- If you need a commercial license please contact us at
hadjarcreative@gmail.com :)

- Any donation are very appreciated. Paypal account for donation : https://www.paypal.me/misasulaiman


Thank you,
Best regards
Hadjar Creative